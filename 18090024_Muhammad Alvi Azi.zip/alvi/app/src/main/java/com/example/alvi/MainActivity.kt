package com.example.alvi

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onLogout(view: View) {
        startActivity(Intent(this, LoginActivity::class.java))
    }

    fun onCalculate(view: View) {
        startActivity(Intent(this, CalculateActivity::class.java))
    }

    fun onAbout(view: View) {
        startActivity(Intent(this, AboutActivity::class.java))
    }
}